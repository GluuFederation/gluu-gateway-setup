local storage = {}

function storage.new()
    return storage
end

return storage
